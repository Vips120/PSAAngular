export class Course {
    getCourse(): string[]{
        return ["Reactjs", "Nodejs", "Mongodb", "Angular"];
    };

    getproduct(): string[]{
        return ["TV", "Laptop", "Ac"];
    }
}